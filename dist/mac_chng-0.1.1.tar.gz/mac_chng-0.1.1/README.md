# mac-chng

This script changes the style of writing the MAC address in accordance with the requirements of various vendors of network equipment.